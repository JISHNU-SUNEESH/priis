<?php

$security_areas['SA_REPORT_GENERATOR'] = array(SS_SPEC|155, _("Report Generator"));

?>
