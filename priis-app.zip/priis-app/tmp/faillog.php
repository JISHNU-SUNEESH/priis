<?php
/*
Login attempts info.
*/
$login_faillog = array (
  0 => 
  array (
    '::1' => 0,
    'last' => '',
  ),
);
